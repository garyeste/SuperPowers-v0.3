#include "samplebank.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <limits>

#if defined(_WIN32)
#include <windows.h>
#include <shlobj.h>
#endif

namespace Steinberg::Vst::RockTrigger {

namespace {

constexpr std::array<const char*, 5> kFileNames {
    "modern_rock.wav",
    "modern_metal.wav",
    "alternative.wav",
    "progressive_rock.wav",
    "trap_rock.wav",
};

uint16_t readU16LE (const uint8_t* p)
{
    return static_cast<uint16_t> (p[0] | (static_cast<uint16_t> (p[1]) << 8));
}

uint32_t readU32LE (const uint8_t* p)
{
    return static_cast<uint32_t> (p[0]) |
           (static_cast<uint32_t> (p[1]) << 8) |
           (static_cast<uint32_t> (p[2]) << 16) |
           (static_cast<uint32_t> (p[3]) << 24);
}

int32_t readS24LE (const uint8_t* p)
{
    int32_t v = static_cast<int32_t> (p[0]) |
                (static_cast<int32_t> (p[1]) << 8) |
                (static_cast<int32_t> (p[2]) << 16);
    if (v & 0x00800000)
        v |= ~0x00FFFFFF;
    return v;
}

int32_t readS32LE (const uint8_t* p)
{
    return static_cast<int32_t> (readU32LE (p));
}

bool idEquals (const char id[4], const char* expected)
{
    return std::memcmp (id, expected, 4) == 0;
}

} // namespace

const LoadedSample& SampleBank::sample (int index) const noexcept
{
    static const LoadedSample empty;
    if (index < 0 || index >= static_cast<int> (samples_.size ()))
        return empty;
    return samples_[static_cast<size_t> (index)];
}

std::filesystem::path SampleBank::findSampleFolder ()
{
#if defined(_WIN32)
    PWSTR docs = nullptr;
    if (SUCCEEDED (SHGetKnownFolderPath (FOLDERID_Documents, KF_FLAG_DEFAULT, nullptr, &docs)) && docs)
    {
        std::filesystem::path result (docs);
        CoTaskMemFree (docs);
        return result / L"RockTrigger Samples";
    }
#endif

    if (const char* home = std::getenv ("HOME"))
        return std::filesystem::path (home) / "Documents" / "RockTrigger Samples";

    return std::filesystem::current_path () / "RockTrigger Samples";
}

bool SampleBank::loadForSampleRate (double targetSampleRate)
{
    folder_ = findSampleFolder ();
    maxFrames_ = 0;
    bool anyLoaded = false;

    for (size_t i = 0; i < samples_.size (); ++i)
    {
        samples_[i] = {};
        errors_[i].clear ();

        DecodedWav wav;
        const auto path = folder_ / kFileNames[i];
        if (!decodeWav (path, wav, errors_[i]))
            continue;

        samples_[i] = resample (wav, targetSampleRate);
        if (!samples_[i].valid ())
        {
            errors_[i] = "File decoded, but produced no audio frames.";
            continue;
        }

        anyLoaded = true;
        maxFrames_ = std::max<uint32_t> (
            maxFrames_,
            static_cast<uint32_t> (std::min<size_t> (samples_[i].frames (), std::numeric_limits<uint32_t>::max ())));
    }

    return anyLoaded;
}

bool SampleBank::decodeWav (const std::filesystem::path& file, DecodedWav& out, std::string& error)
{
    std::ifstream in (file, std::ios::binary);
    if (!in)
    {
        error = "File not found: " + file.u8string ();
        return false;
    }

    char riff[4] {};
    uint8_t sizeBytes[4] {};
    char wave[4] {};
    in.read (riff, 4);
    in.read (reinterpret_cast<char*> (sizeBytes), 4);
    in.read (wave, 4);

    if (!in || !idEquals (riff, "RIFF") || !idEquals (wave, "WAVE"))
    {
        error = "Not a RIFF/WAVE file.";
        return false;
    }

    uint16_t formatTag = 0;
    uint16_t channels = 0;
    uint32_t sampleRate = 0;
    uint16_t blockAlign = 0;
    uint16_t bitsPerSample = 0;
    std::vector<uint8_t> audioData;
    bool haveFmt = false;
    bool haveData = false;

    while (in && !(haveFmt && haveData))
    {
        char chunkId[4] {};
        uint8_t chunkSizeBytes[4] {};
        in.read (chunkId, 4);
        in.read (reinterpret_cast<char*> (chunkSizeBytes), 4);
        if (!in)
            break;

        const uint32_t chunkSize = readU32LE (chunkSizeBytes);

        if (idEquals (chunkId, "fmt "))
        {
            std::vector<uint8_t> fmt (chunkSize);
            if (chunkSize > 0)
                in.read (reinterpret_cast<char*> (fmt.data ()), chunkSize);
            if (!in || fmt.size () < 16)
            {
                error = "Invalid fmt chunk.";
                return false;
            }

            formatTag = readU16LE (&fmt[0]);
            channels = readU16LE (&fmt[2]);
            sampleRate = readU32LE (&fmt[4]);
            blockAlign = readU16LE (&fmt[12]);
            bitsPerSample = readU16LE (&fmt[14]);

            // WAVE_FORMAT_EXTENSIBLE: the first two bytes of SubFormat identify PCM (1) or IEEE float (3).
            if (formatTag == 0xFFFE && fmt.size () >= 40)
                formatTag = readU16LE (&fmt[24]);

            haveFmt = true;
        }
        else if (idEquals (chunkId, "data"))
        {
            audioData.resize (chunkSize);
            if (chunkSize > 0)
                in.read (reinterpret_cast<char*> (audioData.data ()), chunkSize);
            if (!in)
            {
                error = "Invalid data chunk.";
                return false;
            }
            haveData = true;
        }
        else
        {
            in.seekg (chunkSize, std::ios::cur);
        }

        if (chunkSize & 1u)
            in.seekg (1, std::ios::cur); // RIFF chunks are word aligned.
    }

    if (!haveFmt || !haveData)
    {
        error = "Missing fmt or data chunk.";
        return false;
    }
    if (channels < 1 || channels > 2 || sampleRate == 0 || blockAlign == 0)
    {
        error = "Only mono/stereo WAV files are supported.";
        return false;
    }
    if (formatTag != 1 && formatTag != 3)
    {
        error = "Unsupported WAV encoding (use PCM or 32-bit float).";
        return false;
    }

    const size_t frameCount = audioData.size () / blockAlign;
    if (frameCount == 0)
    {
        error = "WAV contains no samples.";
        return false;
    }

    out.sampleRate = static_cast<int> (sampleRate);
    out.channels = static_cast<int> (channels);
    out.interleaved.resize (frameCount * channels);

    const size_t bytesPerSample = blockAlign / channels;
    if (bytesPerSample == 0)
    {
        error = "Invalid WAV block alignment.";
        return false;
    }

    for (size_t frame = 0; frame < frameCount; ++frame)
    {
        for (size_t ch = 0; ch < channels; ++ch)
        {
            const uint8_t* p = audioData.data () + frame * blockAlign + ch * bytesPerSample;
            float v = 0.f;

            if (formatTag == 3 && bitsPerSample == 32 && bytesPerSample >= 4)
            {
                uint32_t raw = readU32LE (p);
                static_assert (sizeof (float) == sizeof (uint32_t));
                std::memcpy (&v, &raw, sizeof (float));
            }
            else if (formatTag == 1 && bitsPerSample == 16 && bytesPerSample >= 2)
            {
                const int16_t s = static_cast<int16_t> (readU16LE (p));
                v = static_cast<float> (s / 32768.0);
            }
            else if (formatTag == 1 && bitsPerSample == 24 && bytesPerSample >= 3)
            {
                v = static_cast<float> (readS24LE (p) / 8388608.0);
            }
            else if (formatTag == 1 && bitsPerSample == 32 && bytesPerSample >= 4)
            {
                v = static_cast<float> (readS32LE (p) / 2147483648.0);
            }
            else
            {
                error = "Supported WAV formats: PCM 16/24/32-bit or IEEE float 32-bit.";
                return false;
            }

            out.interleaved[frame * channels + ch] = std::clamp (v, -1.f, 1.f);
        }
    }

    return true;
}

LoadedSample SampleBank::resample (const DecodedWav& source, double targetSampleRate)
{
    LoadedSample result;
    if (source.sampleRate <= 0 || targetSampleRate <= 0.0 || source.channels < 1 || source.channels > 2)
        return result;

    const size_t sourceFrames = source.interleaved.size () / static_cast<size_t> (source.channels);
    if (sourceFrames == 0)
        return result;

    const double ratio = targetSampleRate / static_cast<double> (source.sampleRate);
    const size_t targetFrames = std::max<size_t> (1, static_cast<size_t> (std::llround (sourceFrames * ratio)));

    result.left.resize (targetFrames);
    result.stereo = source.channels == 2;
    if (result.stereo)
        result.right.resize (targetFrames);

    auto sourceAt = [&] (size_t frame, int channel) -> float {
        frame = std::min (frame, sourceFrames - 1);
        const int actualChannel = source.channels == 1 ? 0 : channel;
        return source.interleaved[frame * static_cast<size_t> (source.channels) + static_cast<size_t> (actualChannel)];
    };

    for (size_t i = 0; i < targetFrames; ++i)
    {
        const double srcPos = static_cast<double> (i) / ratio;
        const size_t i0 = std::min (static_cast<size_t> (srcPos), sourceFrames - 1);
        const size_t i1 = std::min (i0 + 1, sourceFrames - 1);
        const float frac = static_cast<float> (srcPos - static_cast<double> (i0));

        const float l0 = sourceAt (i0, 0);
        const float l1 = sourceAt (i1, 0);
        result.left[i] = l0 + (l1 - l0) * frac;

        if (result.stereo)
        {
            const float r0 = sourceAt (i0, 1);
            const float r1 = sourceAt (i1, 1);
            result.right[i] = r0 + (r1 - r0) * frac;
        }
    }

    return result;
}

} // namespace Steinberg::Vst::RockTrigger
