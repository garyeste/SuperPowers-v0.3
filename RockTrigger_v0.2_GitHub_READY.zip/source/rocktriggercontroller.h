#pragma once

#include "public.sdk/source/vst/vsteditcontroller.h"

namespace Steinberg::Vst::RockTrigger {

class RockTriggerController final : public EditControllerEx1
{
public:
    static FUnknown* createInstance (void*) { return static_cast<IEditController*> (new RockTriggerController ()); }

    tresult PLUGIN_API initialize (FUnknown* context) override;
    tresult PLUGIN_API setComponentState (IBStream* state) override;
    IPlugView* PLUGIN_API createView (FIDString name) override;
};

} // namespace Steinberg::Vst::RockTrigger
