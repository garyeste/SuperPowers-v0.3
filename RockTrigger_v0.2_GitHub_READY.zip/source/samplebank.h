#pragma once

#include <array>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace Steinberg::Vst::RockTrigger {

struct LoadedSample
{
    std::vector<float> left;
    std::vector<float> right;
    bool stereo {false};

    bool valid () const noexcept { return !left.empty (); }
    size_t frames () const noexcept { return left.size (); }

    float at (int channel, size_t frame) const noexcept
    {
        if (frame >= left.size ())
            return 0.f;
        if (channel == 0 || !stereo || right.empty ())
            return left[frame];
        return right[frame];
    }
};

class SampleBank
{
public:
    bool loadForSampleRate (double targetSampleRate);
    const LoadedSample& sample (int index) const noexcept;
    uint32_t maxFrames () const noexcept { return maxFrames_; }
    const std::filesystem::path& folder () const noexcept { return folder_; }
    const std::array<std::string, 5>& errors () const noexcept { return errors_; }

private:
    struct DecodedWav
    {
        int sampleRate {0};
        int channels {0};
        std::vector<float> interleaved;
    };

    static std::filesystem::path findSampleFolder ();
    static bool decodeWav (const std::filesystem::path& file, DecodedWav& out, std::string& error);
    static LoadedSample resample (const DecodedWav& source, double targetSampleRate);

    std::array<LoadedSample, 5> samples_;
    std::array<std::string, 5> errors_;
    std::filesystem::path folder_;
    uint32_t maxFrames_ {0};
};

} // namespace Steinberg::Vst::RockTrigger
