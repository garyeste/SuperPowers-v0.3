#define MyAppName "RockTrigger"
#define MyAppVersion "0.2.0"
#define MyAppPublisher "Gary Este"

[Setup]
AppId={{8A221B31-C7C1-4FA0-9A1B-92A29A5046E7}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\Common\VST3
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=output
OutputBaseFilename=RockTrigger-v{#MyAppVersion}-Windows-x64-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName=RockTrigger VST3

[Dirs]
Name: "{userdocs}\RockTrigger Samples"

[Files]
Source: "..\dist\RockTrigger.vst3\*"; DestDir: "{localappdata}\Programs\Common\VST3\RockTrigger.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\samples\README.txt"; DestDir: "{userdocs}\RockTrigger Samples"; Flags: ignoreversion onlyifdoesntexist
Source: "..\samples\*.wav"; DestDir: "{userdocs}\RockTrigger Samples"; Flags: ignoreversion skipifsourcedoesntexist

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    Log('RockTrigger installed. Rescan VST3 plug-ins in the DAW if necessary.');
  end;
end;
