RockTrigger sample folder
=========================

Put these WAV files here using the exact names below:

modern_rock.wav
modern_metal.wav
alternative.wav
progressive_rock.wav
trap_rock.wav

RockTrigger supports mono/stereo PCM 16/24/32-bit WAV and 32-bit float WAV.
The files are loaded/resampled when the plug-in processing setup is prepared.

If these WAV files are present in this repository's samples folder when the
Windows installer is built, the installer will bundle them automatically.
