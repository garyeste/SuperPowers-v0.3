#include "rocktriggerprocessor.h"
#include "rocktriggerids.h"

#include "base/source/fstreamer.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "pluginterfaces/vst/vstspeaker.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <type_traits>

namespace Steinberg::Vst::RockTrigger {

namespace {

float dbToLinear (double db)
{
    return static_cast<float> (std::pow (10.0, db / 20.0));
}

} // namespace

RockTriggerProcessor::RockTriggerProcessor ()
{
    retriggerNormalized_ = kRetriggerDefaultNormalized;
    setControllerClass (kControllerUID);
}

tresult PLUGIN_API RockTriggerProcessor::initialize (FUnknown* context)
{
    const auto result = AudioEffect::initialize (context);
    if (result != kResultOk)
        return result;

    addAudioInput (STR16 ("Audio In"), SpeakerArr::kStereo);
    addAudioOutput (STR16 ("Audio Out"), SpeakerArr::kStereo);
    return kResultOk;
}

tresult PLUGIN_API RockTriggerProcessor::setBusArrangements (SpeakerArrangement* inputs, int32 numIns,
                                                              SpeakerArrangement* outputs, int32 numOuts)
{
    if (numIns != 1 || numOuts != 1)
        return kResultFalse;

    const auto in = inputs[0];
    const auto out = outputs[0];
    const bool supported = (in == SpeakerArr::kMono && out == SpeakerArr::kMono) ||
                           (in == SpeakerArr::kStereo && out == SpeakerArr::kStereo);
    if (!supported)
        return kResultFalse;

    return AudioEffect::setBusArrangements (inputs, numIns, outputs, numOuts);
}

tresult PLUGIN_API RockTriggerProcessor::setupProcessing (ProcessSetup& setup)
{
    const auto result = AudioEffect::setupProcessing (setup);
    if (result != kResultOk)
        return result;

    sampleRate_ = setup.sampleRate > 0.0 ? setup.sampleRate : 44100.0;

    // Disk I/O and resampling happen here, before realtime process() starts.
    sampleBank_.loadForSampleRate (sampleRate_);

    const double releaseSeconds = 0.012; // fast envelope: suitable for isolated drum/percussive tracks.
    releaseCoeff_ = static_cast<float> (std::exp (-1.0 / (releaseSeconds * sampleRate_)));
    updateRetriggerSamples ();

    resetRuntime ();
    return kResultOk;
}

tresult PLUGIN_API RockTriggerProcessor::setProcessing (TBool state)
{
    if (!state)
        resetRuntime ();
    return AudioEffect::setProcessing (state);
}

tresult PLUGIN_API RockTriggerProcessor::canProcessSampleSize (int32 symbolicSampleSize)
{
    return (symbolicSampleSize == kSample32 || symbolicSampleSize == kSample64) ? kResultTrue : kResultFalse;
}

void RockTriggerProcessor::applyParameterChanges (IParameterChanges* changes)
{
    if (!changes)
        return;

    const int32 count = changes->getParameterCount ();
    for (int32 i = 0; i < count; ++i)
    {
        auto* queue = changes->getParameterData (i);
        if (!queue || queue->getPointCount () <= 0)
            continue;

        int32 sampleOffset = 0;
        ParamValue value = 0.0;
        if (queue->getPoint (queue->getPointCount () - 1, sampleOffset, value) != kResultTrue)
            continue;

        if (queue->getParameterId () == kSoundId)
        {
            soundNormalized_ = std::clamp (value, 0.0, 1.0);
            selectedSound_ = std::clamp (static_cast<int> (std::llround (soundNormalized_ * (kNumSounds - 1))), 0, kNumSounds - 1);
        }
        else if (queue->getParameterId () == kThresholdId)
        {
            thresholdNormalized_ = std::clamp (value, 0.0, 1.0);
            const double db = kThresholdMinDb + thresholdNormalized_ * (kThresholdMaxDb - kThresholdMinDb);
            thresholdLinear_ = dbToLinear (db);
        }
        else if (queue->getParameterId () == kRetriggerId)
        {
            retriggerNormalized_ = std::clamp (value, 0.0, 1.0);
            updateRetriggerSamples ();
        }
    }
}


void RockTriggerProcessor::updateRetriggerSamples () noexcept
{
    const double ms = kRetriggerMinMs + retriggerNormalized_ * (kRetriggerMaxMs - kRetriggerMinMs);
    cooldownSamples_ = std::max (1, static_cast<int> (std::llround (ms * 0.001 * sampleRate_)));
}

void RockTriggerProcessor::trigger ()
{
    if (!sampleBank_.sample (selectedSound_).valid ())
        return;

    Voice* target = nullptr;
    for (auto& voice : voices_)
    {
        if (!voice.active)
        {
            target = &voice;
            break;
        }
    }

    if (!target)
    {
        target = &*std::min_element (voices_.begin (), voices_.end (), [] (const Voice& a, const Voice& b) {
            return a.serial < b.serial;
        });
    }

    target->active = true;
    target->sampleIndex = selectedSound_;
    target->position = 0;
    target->serial = voiceSerial_++;
}

void RockTriggerProcessor::resetRuntime ()
{
    for (auto& voice : voices_)
        voice = {};
    envelope_ = 0.f;
    cooldownRemaining_ = 0;
    armed_ = true;
}

bool RockTriggerProcessor::anyVoiceActive () const noexcept
{
    for (const auto& voice : voices_)
        if (voice.active)
            return true;
    return false;
}

template <typename SampleType>
tresult RockTriggerProcessor::processAudio (ProcessData& data)
{
    if (data.numInputs < 1 || data.numOutputs < 1 || !data.inputs || !data.outputs)
        return kResultOk;

    const int32 inputChannels = data.inputs[0].numChannels;
    const int32 outputChannels = data.outputs[0].numChannels;
    if (inputChannels <= 0 || outputChannels <= 0)
        return kResultOk;

    auto** inputs = std::is_same_v<SampleType, Sample32> ?
        reinterpret_cast<SampleType**> (data.inputs[0].channelBuffers32) :
        reinterpret_cast<SampleType**> (data.inputs[0].channelBuffers64);
    auto** outputs = std::is_same_v<SampleType, Sample32> ?
        reinterpret_cast<SampleType**> (data.outputs[0].channelBuffers32) :
        reinterpret_cast<SampleType**> (data.outputs[0].channelBuffers64);

    if (!inputs || !outputs)
        return kResultOk;

    const auto& selected = sampleBank_.sample (selectedSound_);

    // If the chosen slot is missing, stay safe and pass the source through instead of muting the track.
    if (!selected.valid ())
    {
        for (int32 ch = 0; ch < outputChannels; ++ch)
        {
            const int32 srcCh = std::min (ch, inputChannels - 1);
            if (!outputs[ch])
                continue;
            if (inputs[srcCh] == outputs[ch])
                continue;
            if (inputs[srcCh])
                std::memcpy (outputs[ch], inputs[srcCh], static_cast<size_t> (data.numSamples) * sizeof (SampleType));
            else
                std::fill_n (outputs[ch], data.numSamples, static_cast<SampleType> (0));
        }
        data.outputs[0].silenceFlags = data.inputs[0].silenceFlags;
        return kResultOk;
    }

    bool wroteAudio = false;

    for (int32 i = 0; i < data.numSamples; ++i)
    {
        float detector = 0.f;
        for (int32 ch = 0; ch < inputChannels; ++ch)
        {
            if (inputs[ch])
                detector = std::max (detector, static_cast<float> (std::abs (inputs[ch][i])));
        }

        envelope_ = detector >= envelope_ ? detector : envelope_ * releaseCoeff_;

        if (cooldownRemaining_ > 0)
            --cooldownRemaining_;

        if (armed_ && cooldownRemaining_ <= 0 && envelope_ >= thresholdLinear_)
        {
            trigger ();
            armed_ = false;
            cooldownRemaining_ = cooldownSamples_;
        }
        else if (!armed_ && cooldownRemaining_ <= 0 && envelope_ <= thresholdLinear_ * 0.35f)
        {
            armed_ = true;
        }

        float outL = 0.f;
        float outR = 0.f;
        for (auto& voice : voices_)
        {
            if (!voice.active)
                continue;

            const auto& s = sampleBank_.sample (voice.sampleIndex);
            if (!s.valid () || voice.position >= s.frames ())
            {
                voice.active = false;
                continue;
            }

            outL += s.at (0, voice.position);
            outR += s.stereo ? s.at (1, voice.position) : s.at (0, voice.position);
            ++voice.position;
            if (voice.position >= s.frames ())
                voice.active = false;
        }

        if (outL != 0.f || outR != 0.f)
            wroteAudio = true;

        if (outputChannels == 1)
        {
            if (outputs[0])
                outputs[0][i] = static_cast<SampleType> ((outL + outR) * 0.5f);
        }
        else
        {
            if (outputs[0])
                outputs[0][i] = static_cast<SampleType> (outL);
            if (outputs[1])
                outputs[1][i] = static_cast<SampleType> (outR);
            for (int32 ch = 2; ch < outputChannels; ++ch)
                if (outputs[ch])
                    outputs[ch][i] = static_cast<SampleType> (0);
        }
    }

    data.outputs[0].silenceFlags = (!wroteAudio && !anyVoiceActive ())
        ? ((outputChannels >= 64) ? std::numeric_limits<uint64>::max () : ((uint64 {1} << outputChannels) - 1))
        : 0;

    return kResultOk;
}

tresult PLUGIN_API RockTriggerProcessor::process (ProcessData& data)
{
    applyParameterChanges (data.inputParameterChanges);

    if (data.numSamples == 0)
    {
        resetRuntime (); // handle a host flush call without allocations or I/O.
        return kResultOk;
    }

    if (data.symbolicSampleSize == kSample64)
        return processAudio<Sample64> (data);
    return processAudio<Sample32> (data);
}

tresult PLUGIN_API RockTriggerProcessor::setState (IBStream* state)
{
    if (!state)
        return kResultFalse;

    IBStreamer stream (state, kLittleEndian);
    float sound = 0.f;
    float threshold = 0.6f;
    float retrigger = static_cast<float> (kRetriggerDefaultNormalized);
    if (!stream.readFloat (sound) || !stream.readFloat (threshold))
        return kResultFalse;

    // v0.1 stored only sound + threshold. If the third value is absent, keep the v0.2 default.
    stream.readFloat (retrigger);

    soundNormalized_ = std::clamp<double> (sound, 0.0, 1.0);
    thresholdNormalized_ = std::clamp<double> (threshold, 0.0, 1.0);
    retriggerNormalized_ = std::clamp<double> (retrigger, 0.0, 1.0);
    selectedSound_ = std::clamp (static_cast<int> (std::llround (soundNormalized_ * (kNumSounds - 1))), 0, kNumSounds - 1);
    const double db = kThresholdMinDb + thresholdNormalized_ * (kThresholdMaxDb - kThresholdMinDb);
    thresholdLinear_ = dbToLinear (db);
    updateRetriggerSamples ();
    return kResultOk;
}

tresult PLUGIN_API RockTriggerProcessor::getState (IBStream* state)
{
    if (!state)
        return kResultFalse;

    IBStreamer stream (state, kLittleEndian);
    if (!stream.writeFloat (static_cast<float> (soundNormalized_)) ||
        !stream.writeFloat (static_cast<float> (thresholdNormalized_)) ||
        !stream.writeFloat (static_cast<float> (retriggerNormalized_)))
        return kResultFalse;
    return kResultOk;
}

uint32 PLUGIN_API RockTriggerProcessor::getTailSamples ()
{
    return sampleBank_.maxFrames ();
}

} // namespace Steinberg::Vst::RockTrigger
